#include <stdio.h>
#include <stdlib.h>

// Define function to perform addition operation
float add(float num1, float num2) {
    return num1 + num2;
}

// Define function to perform subtraction operation
float subtract(float num1, float num2) {
    return num1 - num2;
}

// Define function to perform multiplication operation
float multiply(float num1, float num2) {
    return num1 * num2;
}

// Define function to perform division operation
float divide(float num1, float num2) {
    return num1 / num2;
}

// Define main function
int main() {
    float num1, num2, result;
    char operator;

    printf("Enter a math expression with PEMDAS order of operations: ");
    scanf("%f%c%f", &num1, &operator, &num2);

    switch (operator) {
        case '+':
            result = add(num1, num2);
            break;
        case '-':
            result = subtract(num1, num2);
            break;
        case '*':
            result = multiply(num1, num2);
            break;
        case '/':
            result = divide(num1, num2);
            break;
        default:
            printf("Error: Invalid operator");
            return 0;
    }

    printf("Result: %.2f", result);
    return 0;
}
